package repositryLayer;

import java.util.ArrayList;
import java.util.List;

import UILayer.StudentUI;

public class IStudentImplementation implements IStudentdao
{
	static List<StudentUI> ss=new ArrayList<StudentUI>();
	@Override
	public void addStudent(StudentUI student) {
		//ss.add(student);
		
		
	}

	@Override
	public void deleteStudent() {
		
		
	}

	@Override
	public void updateStudent() {
	
		
	}

	@Override
	public void displayStudent() {
		
		
	}

	@Override
	public void getStudentName() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getStudentId() {
		// TODO Auto-generated method stub
		
	}

}
